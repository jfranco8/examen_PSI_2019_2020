from django.contrib import admin
from datamodel.models import Game, Move
# Register your models here.
admin.site.register(Game)
admin.site.register(Move)
