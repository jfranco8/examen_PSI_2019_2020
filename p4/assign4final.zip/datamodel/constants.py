
ERROR_MESSAGE_ID = 'Mensaje de error de ID'
MSG_ERROR_INVALID_CELL = "Invalid cell for a cat or the mouse|Gato o ratón en posición no válida"
MSG_ERROR_GAMESTATUS = "Game status not valid|Estado no válido"
MSG_ERROR_MOVE = "Move not allowed|Movimiento no permitido"
MSG_ERROR_NEW_COUNTER = "Insert not allowed|Inseción no permitida"
GAME_SELECTED_SESSION_ID = "game_id"
JOIN_GAME_ERROR_NOGAME = "There is no available games|No hay juegos disponibles"
